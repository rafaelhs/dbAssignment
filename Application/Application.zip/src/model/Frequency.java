package model;

public class Frequency {

    private int idCard;
    private int idChampionship;
    private int quantity;

    public int getIdCard() {
        return idCard;
    }

    public void setIdCard(int idCard) {
        this.idCard = idCard;
    }

    public int getIdChampionship() {
        return idChampionship;
    }

    public void setIdChampionship(int idChampionship) {
        this.idChampionship = idChampionship;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
